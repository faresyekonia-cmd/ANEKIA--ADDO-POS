# ANETH DLDM POS V2 — Kujenga APK kwa simu pekee

Project hii imeandaliwa kwa cloud build. Huhitaji Android Studio kwenye simu.

## Hatua
1. Fungua GitHub kwenye Chrome na ingia kwenye akaunti yako.
2. Tengeneza repository mpya, mfano `ANETH_DLDM_POS_V2`.
3. Upload **maudhui yote ya folder hii** (si ZIP ndani ya repository).
4. Fungua **Actions** → workflow **Build ANETH DLDM POS APK** → **Run workflow**.
5. Ikimaliza, fungua run iliyofanikiwa → sehemu ya **Artifacts** → pakua `ANETH-DLDM-POS-debug`.
6. Fungua ZIP uliyo-download, kisha install `app-debug.apk` kwenye Android.

## Build settings
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk: 35
- minSdk: 23
- targetSdk: 35

## POS
- Admin PIN: 1234
- Cashier PIN: 1111
- Offline SQLite database
- Mauzo: leo/wiki/mwezi/tarehe maalum
- Export: CSV inayofunguka Excel
