ANETH DLDM POS V2
Dawa zilizoingizwa kutoka Excel: 109

Kipengele kipya:
1. Admin anaweka bei ya dawa mara moja kwenye STOCK/DAWA.
2. Cashier akichagua dawa, anaweka IDADI tu.
3. Mfumo unatumia bei iliyohifadhiwa yenyewe na kuhesabu jumla.
4. Cashier harudii kuandika bei kwenye kila mauzo.
5. App inaendelea kufanya kazi offline.
6. `server/` ina msingi wa Boss Dashboard na sync ya cloud. Ili remote viewing ifanye kazi kabisa, server lazima ideployiwe na Android sync client ipewe URL/API key.

PIN: Admin 1234, Cashier 1111

Build APK: Android Studio -> Open project -> Build -> Build APK(s).
