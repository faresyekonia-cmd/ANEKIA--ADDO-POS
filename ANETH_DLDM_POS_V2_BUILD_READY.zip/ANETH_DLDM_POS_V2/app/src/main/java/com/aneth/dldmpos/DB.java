package com.aneth.dldmpos;
import android.content.*; import android.database.sqlite.*;
public class DB extends SQLiteOpenHelper {
 public DB(Context c){super(c,"aneth_pos.db",null,3);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE drugs(id INTEGER PRIMARY KEY AUTOINCREMENT,generic_name TEXT,brand_name TEXT,strength TEXT,uses TEXT,form TEXT,dosage TEXT,price INTEGER DEFAULT 0,stock INTEGER DEFAULT 0)");
  d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at INTEGER,total INTEGER,paid INTEGER,change_amount INTEGER,cashier TEXT,synced INTEGER DEFAULT 0)");
  d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,drug_id INTEGER,generic_name TEXT,qty INTEGER,unit_price INTEGER,line_total INTEGER)");
  d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
  d.execSQL("INSERT INTO settings VALUES('admin_pin','1234')"); d.execSQL("INSERT INTO settings VALUES('cashier_pin','1111')"); DrugSeed.seed(d);
 }
 public void onUpgrade(SQLiteDatabase d,int oldV,int newV){ }
}
