package com.aneth.dldmpos;
import android.app.*; import android.os.*; import android.content.*; import androidx.core.content.FileProvider; import android.database.*; import android.database.sqlite.*; import android.graphics.Typeface; import android.text.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 DB db; LinearLayout root; String role=""; HashMap<Integer,Integer> cart=new HashMap<>();
 public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);login();}
 TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(20);t.setTypeface(null,Typeface.BOLD);t.setPadding(16,16,16,16);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
 void login(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);root.addView(title("ANETH DLDM POS"));
  EditText p=new EditText(this);p.setHint("PIN");p.setInputType(2);root.addView(p);Button a=btn("INGIA ADMIN");Button c=btn("INGIA CASHIER");root.addView(a);root.addView(c);
  a.setOnClickListener(v->{if(pin(p,"admin_pin")){role="ADMIN";home();}else toast("PIN si sahihi");});
  c.setOnClickListener(v->{if(pin(p,"cashier_pin")){role="CASHIER";home();}else toast("PIN si sahihi");});setContentView(root);}
 boolean pin(EditText p,String k){Cursor c=db.getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});boolean ok=c.moveToFirst()&&p.getText().toString().equals(c.getString(0));c.close();return ok;}
 void home(){root.removeAllViews();root.addView(title("ANETH DLDM POS • "+role));Button s=btn("MAUZO");Button st=btn("STOCK / DAWA");Button r=btn("RIPOTI");root.addView(s);root.addView(st);root.addView(r);s.setOnClickListener(v->sales());st.setOnClickListener(v->inventory());r.setOnClickListener(v->reports());}
 void sales(){root.removeAllViews();root.addView(title("MAUZO — BEI INAJAA YENYEWE"));
  EditText q=new EditText(this);q.setHint("Tafuta dawa");root.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);Button finish=btn("MALIZA MAUZO");root.addView(finish);
  Runnable refresh=()->{list.removeAllViews();Cursor c=db.getReadableDatabase().rawQuery("SELECT id,generic_name,brand_name,price,stock FROM drugs WHERE generic_name LIKE ? OR brand_name LIKE ? ORDER BY generic_name LIMIT 40",new String[]{"%"+q.getText()+"%","%"+q.getText()+"%"});while(c.moveToNext()){int id=c.getInt(0),price=c.getInt(3),stock=c.getInt(4);Button b=btn(c.getString(1)+" • "+c.getString(2)+"\nBei: TZS "+price+" | Stock: "+stock);b.setOnClickListener(v->chooseQty(id,price,stock));list.addView(b);}c.close();};
  q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(Editable e){}});refresh.run();finish.setOnClickListener(v->checkout());}
 void chooseQty(int id,int price,int stock){if(stock<=0){toast("Stock imeisha");return;}EditText q=new EditText(this);q.setHint("Idadi");q.setInputType(2);new AlertDialog.Builder(this).setTitle("Weka IDADI").setMessage("Bei ya dawa: TZS "+price+"\nHutaandika bei. Mfumo utaitumia yenyewe.").setView(q).setPositiveButton("ONGEZA",(d,w)->{int n=0;try{n=Integer.parseInt(q.getText().toString());}catch(Exception e){}if(n<1||n>stock){toast("Idadi si sahihi");return;}cart.put(id,cart.getOrDefault(id,0)+n);toast("Imeongezwa. Jumla itahesabiwa kwa bei ya dawa.");}).setNegativeButton("FUTA",null).show();}
 void checkout(){if(cart.isEmpty()){toast("Cart iko tupu");return;}SQLiteDatabase d=db.getWritableDatabase();int total=0;for(Integer id:cart.keySet()){Cursor c=d.rawQuery("SELECT price,stock FROM drugs WHERE id=?",new String[]{""+id});c.moveToFirst();int q=cart.get(id);if(q>c.getInt(1)){toast("Stock haitoshi");c.close();return;}total+=q*c.getInt(0);c.close();}
  EditText paid=new EditText(this);paid.setHint("Kiasi alicholipa (TZS)");paid.setInputType(2);new AlertDialog.Builder(this).setTitle("Jumla TZS "+total).setView(paid).setPositiveButton("HIFADHI",(x,w)->{int p;try{p=Integer.parseInt(paid.getText().toString());}catch(Exception e){p=0;}if(p<total){toast("Malipo hayatoshi");return;}ContentValues s=new ContentValues();s.put("created_at",System.currentTimeMillis());s.put("total",total);s.put("paid",p);s.put("change_amount",p-total);s.put("cashier",role);long sid=d.insert("sales",null,s);
   for(Integer id:cart.keySet()){Cursor c=d.rawQuery("SELECT generic_name,price FROM drugs WHERE id=?",new String[]{""+id});c.moveToFirst();int q=cart.get(id),pr=c.getInt(1);ContentValues it=new ContentValues();it.put("sale_id",sid);it.put("drug_id",id);it.put("generic_name",c.getString(0));it.put("qty",q);it.put("unit_price",pr);it.put("line_total",q*pr);d.insert("sale_items",null,it);d.execSQL("UPDATE drugs SET stock=stock-? WHERE id=?",new Object[]{q,id});c.close();}cart.clear();toast("Mauzo yamehifadhiwa. Chenji TZS "+(p-total));sales();
  }).setNegativeButton("FUTA",null).show();}
 void inventory(){root.removeAllViews();root.addView(title("STOCK / DAWA"));EditText q=new EditText(this);q.setHint("Tafuta");root.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);if(role.equals("ADMIN")){Button a=btn("ONGEZA DAWA");root.addView(a);a.setOnClickListener(v->addDrug());}
  Runnable refresh=()->{list.removeAllViews();Cursor c=db.getReadableDatabase().rawQuery("SELECT id,generic_name,brand_name,price,stock FROM drugs WHERE generic_name LIKE ? OR brand_name LIKE ? ORDER BY generic_name LIMIT 60",new String[]{"%"+q.getText()+"%","%"+q.getText()+"%"});while(c.moveToNext()){int id=c.getInt(0);Button b=btn(c.getString(1)+" • "+c.getString(2)+"\nBei: TZS "+c.getInt(3)+" | Stock: "+c.getInt(4));if(role.equals("ADMIN"))b.setOnClickListener(v->editDrug(id));list.addView(b);}c.close();};q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(Editable e){}});refresh.run();}
 void addDrug(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText g=new EditText(this);g.setHint("Jina la kijeneriki");EditText b=new EditText(this);b.setHint("Jina la biashara");EditText p=new EditText(this);p.setHint("Bei ya kuuza (TZS)");p.setInputType(2);EditText n=new EditText(this);n.setHint("Idadi");n.setInputType(2);l.addView(g);l.addView(b);l.addView(p);l.addView(n);new AlertDialog.Builder(this).setTitle("ONGEZA DAWA").setView(l).setPositiveButton("HIFADHI",(x,w)->{ContentValues v=new ContentValues();v.put("generic_name",g.getText().toString());v.put("brand_name",b.getText().toString());v.put("price",Integer.parseInt(p.getText().toString()));v.put("stock",Integer.parseInt(n.getText().toString()));db.getWritableDatabase().insert("drugs",null,v);inventory();}).setNegativeButton("FUTA",null).show();}
 void editDrug(int id){Cursor c=db.getReadableDatabase().rawQuery("SELECT generic_name,price,stock FROM drugs WHERE id=?",new String[]{""+id});c.moveToFirst();String name=c.getString(0);int old=c.getInt(1);c.close();EditText p=new EditText(this);p.setInputType(2);p.setText(""+old);EditText n=new EditText(this);n.setInputType(2);n.setHint("Ongeza idadi");LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.addView(p);l.addView(n);new AlertDialog.Builder(this).setTitle(name).setMessage("Weka bei hapa mara moja. Cashier hatarudia kuiandika wakati wa kuuza.").setView(l).setPositiveButton("HIFADHI",(x,w)->{int add=0;try{add=Integer.parseInt(n.getText().toString());}catch(Exception e){}db.getWritableDatabase().execSQL("UPDATE drugs SET price=?,stock=stock+? WHERE id=?",new Object[]{Integer.parseInt(p.getText().toString()),add,id});inventory();}).setNegativeButton("FUTA",null).show();}
 void reports(){
  root.removeAllViews(); root.addView(title("RIPOTI ZA MAUZO"));
  TextView info=new TextView(this); info.setPadding(16,8,16,8); root.addView(info);
  LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.VERTICAL); root.addView(buttons);
  Button today=btn("MAUZO YA LEO"); Button week=btn("MAUZO YA WIKI"); Button month=btn("MAUZO YA MWEZI"); Button custom=btn("MAUZO KWA TAREHE"); Button exportToday=btn("EXPORT LEO → CSV / EXCEL"); Button exportWeek=btn("EXPORT WIKI → CSV / EXCEL"); Button exportMonth=btn("EXPORT MWEZI → CSV / EXCEL"); Button exportCustom=btn("EXPORT TAREHE → CSV / EXCEL"); Button top=btn("DAWA ZILIZOUZWA ZAIDI");
  buttons.addView(today); buttons.addView(week); buttons.addView(month); buttons.addView(custom); buttons.addView(exportToday); buttons.addView(exportWeek); buttons.addView(exportMonth); buttons.addView(exportCustom); buttons.addView(top);
  today.setOnClickListener(v->showPeriodReport("LEO",startOfDay(System.currentTimeMillis()),System.currentTimeMillis(),info));
  week.setOnClickListener(v->showPeriodReport("WIKI HII",startOfWeek(System.currentTimeMillis()),System.currentTimeMillis(),info));
  month.setOnClickListener(v->showPeriodReport("MWEZI HUU",startOfMonth(System.currentTimeMillis()),System.currentTimeMillis(),info));
  custom.setOnClickListener(v->customDate(info));
  top.setOnClickListener(v->topProducts());
  exportToday.setOnClickListener(v->exportCsv("Mauzo_Leo",startOfDay(System.currentTimeMillis()),System.currentTimeMillis()));
  exportWeek.setOnClickListener(v->exportCsv("Mauzo_Wiki",startOfWeek(System.currentTimeMillis()),System.currentTimeMillis()));
  exportMonth.setOnClickListener(v->exportCsv("Mauzo_Mwezi",startOfMonth(System.currentTimeMillis()),System.currentTimeMillis()));
  exportCustom.setOnClickListener(v->customExport());
  showPeriodReport("LEO",startOfDay(System.currentTimeMillis()),System.currentTimeMillis(),info);
 }
 long startOfDay(long t){java.util.Calendar c=java.util.Calendar.getInstance();c.setTimeInMillis(t);c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
 long startOfWeek(long t){java.util.Calendar c=java.util.Calendar.getInstance();c.setTimeInMillis(startOfDay(t));int day=c.get(java.util.Calendar.DAY_OF_WEEK);int diff=(day==java.util.Calendar.SUNDAY)?6:day-java.util.Calendar.MONDAY;c.add(java.util.Calendar.DAY_OF_MONTH,-diff);return c.getTimeInMillis();}
 long startOfMonth(long t){java.util.Calendar c=java.util.Calendar.getInstance();c.setTimeInMillis(startOfDay(t));c.set(java.util.Calendar.DAY_OF_MONTH,1);return c.getTimeInMillis();}
 String money(long n){return String.format(java.util.Locale.US,"%,d",n);}
 void showPeriodReport(String label,long from,long to,TextView info){
  SQLiteDatabase d=db.getReadableDatabase(); Cursor c=d.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0),COALESCE(SUM(change_amount),0),COUNT(*) FROM sales WHERE created_at>=? AND created_at<?",new String[]{""+from,""+to});
  c.moveToFirst();long sales=c.getLong(0),paid=c.getLong(1),change=c.getLong(2),transactions=c.getLong(3);c.close();
  Cursor q=d.rawQuery("SELECT COALESCE(SUM(qty),0) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.created_at>=? AND s.created_at<?",new String[]{""+from,""+to});q.moveToFirst();long units=q.getLong(0);q.close();
  info.setText("RIPOTI: "+label+"\n\nJumla ya mauzo: TZS "+money(sales)+"\nTransactions: "+transactions+"\nVipande vilivyouzwa: "+units+"\nFedha zilizopokelewa: TZS "+money(paid)+"\nChenji iliyotolewa: TZS "+money(change));
 }
 void customDate(TextView info){
  LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL); EditText date=new EditText(this);date.setHint("YYYY-MM-DD, mfano 2026-10-06"); l.addView(date);
  new AlertDialog.Builder(this).setTitle("CHAGUA TAREHE").setView(l).setPositiveButton("ANGALIA",(x,w)->{try{String[] a=date.getText().toString().trim().split("-");java.util.Calendar c=java.util.Calendar.getInstance();c.set(Integer.parseInt(a[0]),Integer.parseInt(a[1])-1,Integer.parseInt(a[2]),0,0,0);c.set(java.util.Calendar.MILLISECOND,0);long from=c.getTimeInMillis();showPeriodReport(date.getText().toString(),from,from+86400000L,info);}catch(Exception e){toast("Tarehe si sahihi. Tumia YYYY-MM-DD");}}).setNegativeButton("FUTA",null).show();
 }
 void customExport(){
  EditText date=new EditText(this); date.setHint("YYYY-MM-DD, mfano 2026-10-06");
  new AlertDialog.Builder(this).setTitle("EXPORT MAUZO YA TAREHE").setView(date).setPositiveButton("EXPORT",(x,w)->{
   try{String[] a=date.getText().toString().trim().split("-");java.util.Calendar c=java.util.Calendar.getInstance();c.set(Integer.parseInt(a[0]),Integer.parseInt(a[1])-1,Integer.parseInt(a[2]),0,0,0);c.set(java.util.Calendar.MILLISECOND,0);long from=c.getTimeInMillis();exportCsv("Mauzo_"+date.getText().toString().trim(),from,from+86400000L);}
   catch(Exception e){toast("Tarehe si sahihi. Tumia YYYY-MM-DD");}
  }).setNegativeButton("FUTA",null).show();
 }
 void exportCsv(String fileBase,long from,long to){
  try{java.io.File dir=new java.io.File(getCacheDir(),"exports"); if(!dir.exists()) dir.mkdirs();
   java.io.File f=new java.io.File(dir,fileBase+".csv"); java.io.OutputStreamWriter out=new java.io.OutputStreamWriter(new java.io.FileOutputStream(f),"UTF-8");
   out.write("ANETH DLDM POS - RIPOTI YA MAUZO\n"); out.write("Tarehe/Muda,Dawa,Idadi,Bei kwa Moja,Jumla,Cashier\n");
   Cursor c=db.getReadableDatabase().rawQuery("SELECT s.created_at,si.generic_name,si.qty,si.unit_price,si.line_total,s.cashier FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.created_at>=? AND s.created_at<? ORDER BY s.created_at ASC",new String[]{""+from,""+to});
   long grand=0; long units=0; java.text.SimpleDateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault());
   while(c.moveToNext()){String name=c.getString(1).replace("\"","\"\""); String cashier=c.getString(5)==null?"":c.getString(5); out.write("\""+df.format(new java.util.Date(c.getLong(0)))+"\",\""+name+"\","+c.getInt(2)+","+c.getInt(3)+","+c.getInt(4)+",\""+cashier+"\"\n"); grand+=c.getLong(4); units+=c.getLong(2);} c.close();
   Cursor z=db.getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(paid),0),COALESCE(SUM(change_amount),0) FROM sales WHERE created_at>=? AND created_at<?",new String[]{""+from,""+to}); z.moveToFirst(); long transactions=z.getLong(0),paid=z.getLong(1),change=z.getLong(2); z.close();
   out.write("\n"); out.write("Muhtasari\n"); out.write("Transactions,"+transactions+"\n"); out.write("Vipande vilivyouzwa,"+units+"\n"); out.write("Jumla ya mauzo,"+grand+"\n"); out.write("Fedha zilizopokelewa,"+paid+"\n"); out.write("Chenji,"+change+"\n"); out.close();
   android.net.Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f); Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/csv"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(send,"Tuma/Save ripoti ya mauzo"));
  }catch(Exception e){toast("Export imeshindikana: "+e.getMessage());}
 }
 void topProducts(){
  Cursor c=db.getReadableDatabase().rawQuery("SELECT generic_name,SUM(qty) qty,SUM(line_total) total FROM sale_items GROUP BY drug_id,generic_name ORDER BY qty DESC LIMIT 10",null);StringBuilder s=new StringBuilder("TOP 10 ZA DAWA ZILIZOUZWA\n\n");int i=1;while(c.moveToNext()){s.append(i++).append(". ").append(c.getString(0)).append(" — ").append(c.getInt(1)).append(" pcs — TZS ").append(money(c.getLong(2))).append("\n");}c.close();new AlertDialog.Builder(this).setTitle("DAWA ZILIZOUZWA ZAIDI").setMessage(s.length()>25?s.toString():"Hakuna mauzo bado.").setPositiveButton("SAWA",null).show();
 }
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
