SERVER YA ANETH DLDM
- Hii ni backend ya kuunganisha Cashier na Boss.
- Lazima ideployiwe kwenye hosting/VPS yenye HTTPS ili Boss aweze kuona data akiwa mbali.
- API key iwe secret na ndefu.
- Android app ya sasa imeandaliwa offline-first na bei ya dawa inatoka kwenye master price; remote sync ya mwisho inahitaji kuunganishwa na URL/API key ya server yako.
