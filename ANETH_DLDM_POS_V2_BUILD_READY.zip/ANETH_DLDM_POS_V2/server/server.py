import os,sqlite3,time
from flask import Flask,request,jsonify,render_template_string
from flask_cors import CORS
app=Flask(__name__);CORS(app)
DB=os.path.join(os.path.dirname(__file__),"aneth_cloud.db");KEY=os.environ.get("ANETH_API_KEY","BADILI_KEY")
def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
c=conn();c.executescript("""CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,created_at INTEGER,total INTEGER,paid INTEGER,change_amount INTEGER,cashier TEXT,device_id TEXT);CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER,drug_id INTEGER,generic_name TEXT,qty INTEGER,unit_price INTEGER,line_total INTEGER);CREATE TABLE IF NOT EXISTS drugs(id INTEGER PRIMARY KEY,generic_name TEXT,brand_name TEXT,strength TEXT,price INTEGER,stock INTEGER);""");c.commit();c.close()
def auth(): return request.headers.get("X-ANETH-KEY")==KEY
@app.get("/health")
def health(): return jsonify(ok=True)
@app.post("/sync")
def sync():
 if not auth(): return jsonify(error="Unauthorized"),401
 data=request.get_json(force=True);c=conn()
 for s in data.get("sales",[]):
  c.execute("INSERT OR IGNORE INTO sales VALUES(?,?,?,?,?,?,?)",(s["id"],s["created_at"],s["total"],s["paid"],s["change_amount"],s.get("cashier","Cashier"),s.get("device_id","")))
 c.commit();c.close();return jsonify(ok=True)
@app.get("/dashboard")
def dashboard():
 if not auth(): return "Unauthorized",401
 c=conn();sales=c.execute("SELECT * FROM sales ORDER BY created_at DESC LIMIT 100").fetchall();c.close()
 html="""<html><head><meta charset='utf-8'><title>ANETH Boss</title><style>body{font-family:Arial;margin:25px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px}</style></head><body><h1>ANETH DLDM — BOSS</h1><table><tr><th>ID</th><th>Cashier</th><th>Jumla</th><th>Paid</th><th>Chenji</th></tr>{% for s in sales %}<tr><td>{{s['id']}}</td><td>{{s['cashier']}}</td><td>{{s['total']}}</td><td>{{s['paid']}}</td><td>{{s['change_amount']}}</td></tr>{% endfor %}</table></body></html>"""
 return render_template_string(html,sales=sales)
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8080")))
